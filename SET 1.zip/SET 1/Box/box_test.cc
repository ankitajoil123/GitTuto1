#include "box.h"
#include <gtest/gtest.h>
TEST(Box,DefaultConstructor) {
    Box b1;
    EXPECT_EQ(0,b1.getLength());
    EXPECT_EQ(0,b1.getBreadth());
    EXPECT_EQ(0,b1.getHeight());
    //EXPECT_EQ(0,a1.getCustomerName().length());
}


TEST(Box,ParameterizedConstructor) {
    Box b1(1001,200,500);
    EXPECT_EQ(1001,b1.getLength());
    EXPECT_EQ(200,b1.getBreadth());
    EXPECT_EQ(500,b1.getHeight());

   // EXPECT_STREQ("Lippman",a1.getCustomerName().c_str());
    //EXPECT_EQ(4,b1.getLength().length());
   // EXPECT_EQ(5000.0,a1.getBalance());

}
