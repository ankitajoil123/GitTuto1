
#pragma once

#include "gtest/gtest.h"
enum Quadrant {
    Q1=0,
	Q2=1,
	Q3=2,
	Q4=3};
class Point {
	int m_x;
	int m_y;
public:
	Point();
	Point(int, int);
	Point(const Point&);
	double distanceFromOrigin();
	void quadrant();
	void isOrigin();
	void isOnXaxis();
	void isOnYaxis();
	void display();
};
